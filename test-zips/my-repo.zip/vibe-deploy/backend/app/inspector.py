import zipfile

MAX_FILES= 2000
MAX_TOTAL_SIZE=200 * 1024 * 1024 #200MB

MARKERS = {
    "package.json": "node",
    "requirements.txt": "python",
    "pyproject.toml": "python",
    "index.html": "static",
}

def list_zip_files( path: str ):
    with zipfile.ZipFile(path) as zip_file:

        files_in_zipfile = zip_file.infolist()
        if len(files_in_zipfile) > MAX_FILES:
            raise ValueError("ZIP has too many files")

        total_file_size = 0
        for file in files_in_zipfile:
            total_file_size  += file.file_size 

        if total_file_size > MAX_TOTAL_SIZE:
            raise ValueError("ZIP is too big when unzipped")
        
        list_of_file_paths = []
        for file in files_in_zipfile:
            name = file.filename
            if name.startswith("/"):
                raise ValueError(f"Unsafe path in ZIP: {name}")
            elif ".." in name.split("/"):
                raise ValueError(f"Unsafe path in ZIP: {name}")
            elif file.is_dir():
                continue
            else:
                list_of_file_paths.append(name)
            

    return list_of_file_paths


def choose_app_type(app_types : list[str]):
    if "node" in app_types:
        return "node"
    elif "python" in app_types:
        return "python"
    else:
        return "static"

def find_apps(file_names: list[str]):
    marker_files = []
    for name in file_names:
        if "__MACOSX/" in name or "node_modules/" in name:
            continue

        file = name.split("/")[-1]

        if file in MARKERS:
            folder = name.removesuffix(file)

            found = {
                "folder":folder,
                "app_type":MARKERS[file]
            }

            marker_files.append(found) # builds marker files

    if not marker_files:
        raise ValueError("Can't tell what kind of app this is") 


    folders = []
    for item in marker_files:
        if item["folder"] not in folders:
            folders.append(item["folder"]) # creates a folders list for only one instance of the same folder 
    


    services =[]
    for folder in folders:
        types = []
        for item in marker_files:
            if item["folder"] == folder:
                types.append(item["app_type"])

        services.append({"folder": folder, "app_type": choose_app_type(types)}) # creates a list of services(folder and app type) and chooses app type based on choose_app_type function
    

    result = []

    for service in services:
        inside_another = False

        for parent_directory in services:
            if service["folder"] != parent_directory["folder"]:
                if service["folder"].startswith(parent_directory["folder"]):
                    inside_another = True
                    break

        if not inside_another:
            result.append(service) # services(folder and app type ) where the folders are not inside another folder

    return result


    

