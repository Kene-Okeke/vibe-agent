from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import projects, deployments, sources, auth


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],   # the dashboard's address
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(auth.router)
app.include_router(projects.router)
app.include_router(sources.router)
app.include_router(deployments.router)










    

    



    








    




        






    





