from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.tables import ProjectRow, UserRow

def get_my_project(session: Session, project_id:int,user: UserRow):
    project= session.get(ProjectRow, project_id)
    if project is None or user.id!=project.owner_id:
        raise HTTPException(status_code=404, detail="Project not found")

    return project