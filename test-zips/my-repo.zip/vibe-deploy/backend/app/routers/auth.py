import bcrypt
import secrets
from fastapi import APIRouter, Header,HTTPException,Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.schemas import SignupRequest, User,Token,User, LoginRequest
from app.tables import UserRow, engine, TokenRow

router = APIRouter(tags=["auth"])
bearer = HTTPBearer(auto_error=False)      

@router.post("/api/v1/auth/signup", response_model=Token, status_code=201)
def signup(credentials: SignupRequest):
     # 1. tidy the email so "Kene@Example.com" and "kene@example.com" count as the same

    email = credentials.email.strip().lower() # the email comes from the json request (body) )- credentials.email

    # 2. check email and password
    if "@" not in email :
            raise HTTPException(status_code=400, detail="Enter a valid email")
    
    if len(credentials.password)<10:
        raise HTTPException(status_code=400, detail="Password must be at least 10 characters")

    

    # 3. check if email is already taken
    with Session(engine) as session:
        existing = session.scalars(select(UserRow).where(UserRow.email == email)).first()
        if existing is not None:
            raise HTTPException(status_code=409, detail="An account with this email already exists")

    # 4. hash password
                    #    .encode()  text -> bytes, bcrypt only works on bytes
                    #    gensalt()  random salt, so equal passwords get different hashes
                    #    hashpw()   make the one-way hash
                    #    .decode()  bytes -> text for the Mapped[str] column (still the hash)
        password_hash =bcrypt.hashpw(credentials.password.encode(), bcrypt.gensalt()).decode()


    # 5. save the user with hashed password to database
        row = UserRow(email=email, password_hash=password_hash, username=credentials.username)
        
        session.add(row)
        session.flush()

        token = secrets.token_urlsafe(32)
        session.add(TokenRow(token=token, user_id=row.id))
        session.commit()
        
    
        return Token(access_token=token, token_type="bearer")

@router.post("/api/v1/auth/login", response_model=Token)
def login(credentials: LoginRequest):

    email = credentials.email.strip().lower()

    with Session(engine) as session:
        # use the email from the request to fetch the user
        user = session.scalars(select(UserRow).where(UserRow.email == email)).first()

        # no such user, or the password doesn't match the hash
        if user is None or not bcrypt.checkpw(credentials.password.encode(), user.password_hash.encode()):
            raise HTTPException(status_code=401, detail="Wrong email or password")

        # make a random token and remember which user owns it
        token = secrets.token_urlsafe(32)
        session.add(TokenRow(token=token, user_id=user.id))
        session.commit()


        return Token(access_token=token, token_type="bearer")


def get_current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if credentials is None:
        raise HTTPException(status_code=401, detail="Not signed in")
    token = credentials.credentials
        
    with Session(engine) as session:
        token_row = session.scalars(select(TokenRow).where(TokenRow.token == token)).first()
        if token_row is None:
            raise HTTPException(status_code=401, detail="Not signed in")

        user = session.get(UserRow, token_row.user_id)
        return user
    
@router.get("/api/v1/auth/me", response_model=User)
def me(user: UserRow = Depends(get_current_user)):

    return User(id=user.id, email=user.email)


