from fastapi import APIRouter,HTTPException,Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.ownership import get_my_project
from app.schemas import Deployment, DeploymentStatus
from app.tables import DeploymentRow, ProjectRow, engine,UserRow
from app.routers.auth import get_current_user
router = APIRouter(tags=["deployments"])


@router.post("/api/v1/projects/{project_id}/deployments", response_model=Deployment, status_code=202)
def create_deployment(project_id: int, user: UserRow = Depends(get_current_user)):                          

    with Session(engine) as session:

        get_my_project(session, project_id, user)
        row = DeploymentRow(project_id=project_id, status=DeploymentStatus.queued)

        session.add(row)
        session.commit()

    
        return Deployment(id=row.id, project_id=row.project_id, status=row.status)




@router.get("/api/v1/deployments/{deployment_id}", response_model=Deployment)
def get_deployment(deployment_id: int, user: UserRow = Depends(get_current_user)):
    with Session(engine) as session:
        row = session.get(DeploymentRow,deployment_id)
        if  row is None:
            raise HTTPException(status_code=404, detail="Deployment not found")
        project = session.get(ProjectRow, row.project_id)
        if project.owner_id != user.id:
            raise HTTPException(status_code=404, detail="Deployment not found")

        
        return Deployment(id=row.id, project_id=row.project_id, status=row.status)


@router.get("/api/v1/projects/{project_id}/deployments", response_model=list[Deployment])
def list_project_deployments(project_id: int,user: UserRow = Depends(get_current_user)):

    with Session(engine) as session:
        project = get_my_project(session, project_id, user)
        
        rows = session.scalars(
            select(DeploymentRow).where(DeploymentRow.project_id == project_id) # get the deployments for the project id that matches the project id in the url 
        ).all()
        

    result = []
    for row in rows:
        deployment = Deployment(id=row.id, project_id=row.project_id ,status=row.status)

        result.append(deployment)

    return result

