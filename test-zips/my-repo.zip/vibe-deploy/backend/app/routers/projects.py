from pathlib import Path
from fastapi import APIRouter,Form,HTTPException, UploadFile,Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.ownership import get_my_project
from app.schemas import  DeploymentStatus, DeployStarted, Project, SourceStatus
from app.tables import ProjectRow, engine, DeploymentRow,SourceRow, UserRow
from app.routers.auth import get_current_user

router = APIRouter(tags=["projects"])

UPLOAD_DIR = Path("uploads")


@router.post("/api/v1/projects", response_model=DeployStarted, status_code=202)
def deploy_new_project(file: UploadFile, project_name: str = Form(), user: UserRow = Depends(get_current_user)):


    # check what was uploaded then upload contents 
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Only zip files allowed")

    if project_name.strip()=="":
        raise HTTPException(status_code=400, detail="Project name required")

    contents = file.file.read()

    # - write the project name to the database and save that first(project id to be used in next step)
    with Session(engine) as session:
        

        project = ProjectRow(name=project_name, owner_id=user.id )
        session.add(project)
        session.flush()

    # - write the upload info to the database and save that first(source id and storage_path to be referenced by the save to disk)
        source = SourceRow(
            project_id=project.id,
            filename=file.filename,
            size_bytes=len(contents),
            storage_path="",
            status=SourceStatus.uploaded,
        )

        session.add(source)
        session.flush()

    # - create a project folder, create the file path on disk and write its contents to a new source file then save the path to the database
        folder = UPLOAD_DIR/f"project-{project.id}" # uploads/project-1/source-1.zip
        folder.mkdir(parents=True, exist_ok=True)
        path = folder/f"source-{source.id}.zip"
        path.write_bytes(contents)
        source.storage_path = str(path)

        deployment = DeploymentRow(
            project_id=project.id,
            source_id=source.id,
            status= DeploymentStatus.queued,

        )
        session.add(deployment)
        session.commit()

        return DeployStarted(
            project_id=project.id,
            project_name=project.name,
            source_id=source.id,
            storage_path=source.storage_path,
            deployment_id=deployment.id,
            deployment_status=deployment.status,
        )

    
@router.get("/api/v1/projects",response_model=list[Project])
def project_list(user: UserRow = Depends(get_current_user)):
    with Session(engine) as session:
        result=[]
        rows = session.scalars(select(ProjectRow).where(ProjectRow.owner_id==user.id)).all()
        for row in rows:
            project = Project(id=row.id, name=row.name)

            result.append(project)
        return result

@router.get("/api/v1/projects/{project_id}",response_model=Project)
def get_project(project_id: int, user: UserRow = Depends(get_current_user)):
    with Session(engine) as session:
        project = get_my_project(session, project_id, user)

        return Project(id=project.id, name=project.name)


