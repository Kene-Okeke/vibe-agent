from fastapi import UploadFile,HTTPException,APIRouter,Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.ownership import get_my_project
from app.schemas import Source,SourceStatus, DeployStarted, DeploymentStatus
from app.tables import SourceRow,ProjectRow, engine, DeploymentRow,UserRow
from app.routers.projects import UPLOAD_DIR
from app.routers.auth import get_current_user

router = APIRouter(tags=["sources"])

@router.post("/api/v1/projects/{project_id}/sources", response_model=DeployStarted, status_code=202) # This is the api endpoint to upload a source
def update_source(project_id: int, file: UploadFile, user: UserRow = Depends(get_current_user)):
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Only Zip files allowed")
    contents = file.file.read()

    with Session(engine) as session:
        project = get_my_project(session, project_id, user)

        # save an upload as a row to the Db
        # a source is one version of the site, and every upload is a new version. 
        # So every upload gets a new source row.
        source = SourceRow(
            project_id=project_id,
            filename=file.filename,
            size_bytes=len(contents),
            storage_path="",
            status=SourceStatus.uploaded
        )

        session.add(source)
        session.flush()

        folder = UPLOAD_DIR / f"project-{project_id}"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"source-{source.id}.zip"
        path.write_bytes(contents)
        source.storage_path = str(path)

        deployment = DeploymentRow(
        project_id=project.id,
        status = DeploymentStatus.queued,
        source_id=source.id
        
                )
        session.add(deployment)
        session.commit()

        return DeployStarted(
            project_id=project_id,
            project_name=project.name,
            source_id=source.id,
            storage_path=source.storage_path,
            deployment_id=deployment.id,
            deployment_status=deployment.status,
        )
    # file is uploaded
    # file is checked
    # if file paasses check 
    # read file to contents
    # connect to database
    # get the existing project id
    # check if it exists
    # create a source from existing project id and add it to database.
    # add it temporarily
    # create the file path for sources
    # create a deployment
    # return with the deployment of the update 

@router.get("/api/v1/sources/{source_id}", response_model=Source)
def get_source(source_id: int,user: UserRow = Depends(get_current_user)):
    
    with Session(engine) as session:

        row = session.get(SourceRow, source_id)
        
        if row is None:
            raise HTTPException(status_code=404, detail="Source not found")
        project= session.get(ProjectRow, row.project_id)
        if project is None or user.id!=project.owner_id:
            raise HTTPException(status_code=404, detail="Source not found")

    return Source(id=row.id, project_id=row.project_id, filename=row.filename, size_bytes=row.size_bytes, status=row.status)