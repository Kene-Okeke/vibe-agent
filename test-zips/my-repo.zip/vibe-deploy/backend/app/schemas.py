from enum import Enum
from pydantic import BaseModel

class SignupRequest(BaseModel):     # what the frontend sends
    username: str
    email: str
    password: str


class User(BaseModel):              # what you send back
    id: int
    email: str

class Project(BaseModel): # API response
    id: int
    name: str

class LoginRequest(BaseModel):
    email: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str

class Deployment(BaseModel):
    id: int
    project_id: int
    status: DeploymentStatus
class DeployStarted(BaseModel):
    project_id: int
    project_name:str
    source_id: int
    storage_path: str
    deployment_id: int
    deployment_status: DeploymentStatus

class DeploymentStatus(str, Enum):
    queued = "queued"
    building = "building"
    live = "live"
    failed = "failed"



class SourceStatus(str, Enum):
    uploaded = "uploaded"
    inspecting = "inspecting"
    ready = "ready"
    rejected = "rejected"

class Source(BaseModel):  # api response
    id: int
    project_id: int
    filename: str
    size_bytes: int
    status: SourceStatus