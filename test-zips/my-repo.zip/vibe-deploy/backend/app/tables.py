from sqlalchemy import ForeignKey, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String
from app.schemas import DeploymentStatus, SourceStatus
from dotenv import load_dotenv
import os

load_dotenv()
engine = create_engine(os.environ["DATABASE_URL"])

class Base(DeclarativeBase):  # boilerplate:  the parent of all your tables
    type_annotation_map = {str: String(255)}

class UserRow(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(unique=True)
    email: Mapped[str] 
    password_hash: Mapped[str]                        # the hash, never the password

class TokenRow(Base):
    __tablename__ = "tokens"
    id: Mapped[int] = mapped_column(primary_key=True)
    token: Mapped[str] = mapped_column(unique=True)              # the random string the api checks against the token in the frontend request
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))  # who owns the token

class ProjectRow(Base):        # describes the the Rows of the "projects table"
    __tablename__ ="projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id")) # describes 


class DeploymentRow(Base):
    __tablename__ = "deployments"
    id:Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    source_id: Mapped[int | None] = mapped_column(ForeignKey("sources.id"))
    status: Mapped[DeploymentStatus]


class SourceRow(Base):
    __tablename__ = "sources"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] =mapped_column(ForeignKey("projects.id"))
    filename: Mapped[str]
    size_bytes: Mapped[int]
    storage_path: Mapped[str]
    status: Mapped[SourceStatus]

