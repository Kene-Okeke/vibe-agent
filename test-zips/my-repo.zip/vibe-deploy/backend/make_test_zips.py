import zipfile

with zipfile.ZipFile("good.zip", "w") as z:
    z.writestr("my-site/index.html", "<h1>hi</h1>")
    z.writestr("my-site/style.css", "h1 { color: red }")

with zipfile.ZipFile("too-many.zip", "w") as z:
    for i in range(2001):
        z.writestr(f"f{i}.txt", "x")

with zipfile.ZipFile("too-big.zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("big.txt", "0" * (201 * 1024 * 1024))

with zipfile.ZipFile("escape.zip", "w") as z:
    z.writestr("../../evil.txt", "gotcha")

print("made good.zip, too-many.zip, too-big.zip, escape.zip")