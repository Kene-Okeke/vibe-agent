from app.inspector import list_zip_files
from app.inspector import find_apps
# for name in ["good.zip", "too-many.zip", "too-big.zip", "escape.zip"]:
#     try:
#         print(name, "->", list_zip_files("test-zips/" + name))
#     except ValueError as error:
#         print(name, "-> rejected:", error)

print("good.zip:", find_apps(list_zip_files("test-zips/good.zip")))
#print("my repo:", find_apps(list_zip_files("test-zips/my-repo.zip")))