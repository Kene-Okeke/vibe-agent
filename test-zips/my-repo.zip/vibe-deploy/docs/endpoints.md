# API endpoints

All paths start with `/api/v1`. Updated 2026-11-04 (after Lesson 17).

## Rules for every request

- **Login:** every endpoint except sign-up and login needs the header `Authorization: Bearer <access_token>`. Without it, or with a bad token, the answer is **401** `"Not signed in"`.
- **Ownership:** anything with a project in it returns **404** `"Project not found"` if the project doesn't exist **or isn't yours**. We don't reveal other people's projects.
- **500:** any endpoint can return 500 (server bug).

## Endpoints

✅ = built and working · ⏳ = planned, not built yet

| Built | Method | Path | What it does | Success | Errors |
|---|---|---|---|---|---|
| ✅ | POST | `/api/v1/auth/signup` | Create an account and sign in (`{"email", "username", "password"}`), returns `{"access_token", "token_type"}` | 201 | 400 bad email / password under 10 characters, 409 email taken, 422 |
| ✅ | POST | `/api/v1/auth/login` | Sign in (`{"email", "password"}`), returns `{"access_token", "token_type"}` | 200 | 401 wrong email or password, 422 |
| ✅ | GET | `/api/v1/auth/me` | Who is signed in, returns `{"id", "email"}` | 200 | 401 |
| ✅ | POST | `/api/v1/projects` | Deploy button: create a project from a ZIP + name, owned by the logged-in user, save it, start a deployment. Login required: a first-time visitor signs up first, then the frontend sends Deploy with the new token | 202 | 400 not .zip / blank name, 401, 409 name taken (later), 413 too big (later), 422 |
| ✅ | GET | `/api/v1/projects` | List **my** projects, returns `[{"id", "name"}]` | 200 | 401 |
| ✅ | GET | `/api/v1/projects/{project_id}` | Get one of my projects, returns `{"id", "name"}` | 200 | 401, 404 not found or not yours |
| ✅ | POST | `/api/v1/projects/{project_id}/sources` | Upload a ZIP as a new version of my project, start a deployment | 202 | 400 not .zip, 401, 404 not found or not yours, 413 (later), 422 |
| ✅ | GET | `/api/v1/sources/{source_id}` | Get one of my sources, returns `{"id", "project_id", "filename", "size_bytes", "status"}` | 200 | 401, 404 not found or not yours |
| ⏳ | GET | `/api/v1/sources/{source_id}/manifest` | Get the manifest made by inspection | 200 | 401, 404, 409 not inspected yet |
| ⏳ | POST | `/api/v1/sources/{source_id}/inspect` | Request or retry inspection | 202 | 401, 404, 409 already inspecting / wrong state |
| ✅ | POST | `/api/v1/projects/{project_id}/deployments` | Start a new deployment of my project, returns `{"id", "project_id", "status"}` | 202 | 401, 404 not found or not yours, 409 source not ready (later) |
| ✅ | GET | `/api/v1/deployments/{deployment_id}` | One of my deployments, returns `{"id", "project_id", "status"}` | 200 | 401, 404 not found or not yours |
| ⏳ | GET | `/api/v1/deployments/{deployment_id}/logs` | Get a deployment's logs | 200 | 401, 404 |
| ✅ | GET | `/api/v1/projects/{project_id}/deployments` | My project's deployments, returns `[{"id", "project_id", "status"}]` | 200 | 401, 404 not found or not yours |
| ⏳ | POST | `/api/v1/projects/{project_id}/rollback` | Roll back to a past deployment (`{"deployment_id": ...}`) | 202 | 401, 404, 409 that deployment can't be rolled back to, 422 |

## For the frontend

1. After sign-up or login, keep `access_token` (for example in `localStorage`).
2. Send `Authorization: Bearer <access_token>` on every request after that.
3. On a **401**, the token is missing or no longer valid: send the user to the login page.
4. Logging out = delete the saved token.
5. Get project ids from `GET /api/v1/projects`. Never guess them.
6. First-time visitor: keep the chosen ZIP in app state (not `localStorage`, it can't hold files), sign up, then send Deploy with the new token. If the page fully reloads in between, the file is lost and the user picks it again.
7. If Deploy is sent from a `useEffect`, guard it so it runs once: React's dev mode runs effects twice, which would deploy two projects.

## POST /api/v1/projects (Deploy button)

Sent as a form upload (`FormData`), not JSON, with the `Authorization` header:

| Field | Type | Required |
|---|---|---|
| `file` | the ZIP file | yes |
| `project_name` | text, the project name | yes |

Response (202):

```json
{
  "project_id": 1,
  "project_name": "my-portfolio",
  "source_id": 1,
  "storage_path": "uploads/project-1/source-1.zip",
  "deployment_id": 1,
  "deployment_status": "queued"
}
```

`POST /api/v1/projects/{project_id}/sources` takes just `file` and gives the same response shape.

`storage_path` is for development only and will be removed from the response later.
