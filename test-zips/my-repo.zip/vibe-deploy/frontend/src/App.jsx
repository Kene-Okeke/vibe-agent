import { Routes, Route } from "react-router-dom";
import Welcome from "./pages/Welcome";
import CreateAccount from "./pages/CreateAccount";

function App() {
  return (
    <Routes>
      <Route path="/welcome" element={<Welcome />} />;
      <Route path="/create-account" element={<CreateAccount />} />;
    </Routes>
  );
}
export default App;
