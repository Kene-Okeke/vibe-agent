import "../css/VibeAndLogo.css";
import vibedarklogo from "../assets/vibe-deploy-darklogo.png";

function VibeAndLogo() {
  return (
    <div className="vibetextandicon">
      <img className="vibeIcon" src={vibedarklogo} alt="" />
      <span className="vibeandslash">
        vibe/<span className="deployText">deploy</span>
      </span>
    </div>
  );
}

export default VibeAndLogo;
