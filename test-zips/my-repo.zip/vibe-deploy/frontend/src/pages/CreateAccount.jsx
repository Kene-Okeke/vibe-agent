import VibeAndLogo from "../components/VibeAndLogo";
import { Eye, EyeOff, Check, CircleX } from "lucide-react";
import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import normaldarkCircle from "../assets/normaldarkCircle.png";
import "../css/CreateAccount.css";

function CreateAccount() {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState(null);

  const location = useLocation();
  const { file, projectName } = location.state || {};
  const navigate = useNavigate();

  const handleCreateAccount = async () => {
    // Validate input fields
    if (!username || !email || !password || !confirmPassword) {
      setError("Please fill in all fields.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    // Prepare the request payload
    const credentials = {
      username,
      email,
      password,
    };

    try {
      const response = await fetch("/api/v1/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
      });

      if (!response.ok) {
        console.log("Account not created successfully.");
        setError("Unable to create your account. Please try again.");
        return;
      }

      const form = new FormData();
      form.append("file", file);
      form.append("project_name", projectName);

      try {
        const projectResponse = await fetch("/api/v1/projects", {
          method: "POST",
          body: form,
        });

        if (!projectResponse.ok) {
          setError(
            "Account created, but project upload failed. Please try again.",
          );
          navigate("/Deployments", {
            state: { username, error: "Project upload failed." },
          });
          return;
        }

        console.log("Account and project created successfully.");
        {
          /*navigate("/Deployments", {
          state: { username },
        });*/
        }
      } catch (error) {
        console.log("Error saving project:", error);
        setError(
          "Account created, but project upload failed. Please try again.",
        );

        navigate("/Deployments", {
          state: { username, error: "Project upload failed." },
        });
      }
    } catch (error) {
      console.error("Error creating account:", error);
      setError("Unable to create your account. Please try again.");
    }
  };

  return (
    <section className="TwoColumnAuthCont">
      <div className="joinTheBeta">
        <VibeAndLogo />

        <div className="textSection">
          <span>INVITE-ONLY BETA</span>

          <h1>
            Join the <span>beta</span>
          </h1>

          <p>
            Vibe Deploy is invite-only while we scale our build workers. Your
            code from the invite email unlocks your account.
          </p>
        </div>

        <div className="numberSectionwrapper">
          <div className="numberSectionstack">
            <div className="numberOne">1</div>

            <div className="textColumn">
              <h1>Create your account</h1>
              <h3>Invite code, name, email, password</h3>
            </div>
          </div>

          <div className="numberSectionstack">
            <div className="numberOne">2</div>

            <div className="textColumn">
              <h1>Name your workspace</h1>
              <h3>Where your projects live</h3>
            </div>
          </div>

          <div className="numberSectionstack">
            <div className="numberOne">3</div>

            <div className="textColumn">
              <h1>Ship your first project</h1>
              <h3>Upload a ZIP and deployd</h3>
            </div>
          </div>
        </div>

        <div className="leftColumnFooter">
          <h1>© 2026 Vibe Deploy Status: all systems normal</h1>
          <h1>Docs</h1>
        </div>
      </div>

      <div className="rightColumn">
        <div className="CreateAccountStackCard">
          {error && (
            <p className="errorMessage" role="alert">
              {error}
            </p>
          )}

          <h1>Create your account</h1>

          <div className="InvitationtextAndInput">
            <h3>Invitation code</h3>

            <input
              className="InvitationInput"
              type="text"
              placeholder="Enter your invitation code"
            />
          </div>

          <div className="nameAndEmailStack">
            <div className="nameAndInput">
              <h3>Username</h3>

              <input
                className="nameInput"
                type="text"
                placeholder="Enter your name"
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>

            <div className="nameAndInput">
              <h3>Email</h3>

              <input
                className="nameInput"
                type="email"
                placeholder="Enter your email"
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="passwordInputCont">
            <h3>Password</h3>

            <input
              className="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              onChange={(e) => setPassword(e.target.value)}
            />

            <button
              type="button"
              aria-label={showPassword ? "Hide password" : "Show password"}
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <Eye size={20} /> : <EyeOff size={20} />}
            </button>
          </div>

          <div className="passwordStrength">
            <div className="strengthLevel"></div>
            <div className="strengthLevel"></div>
            <div className="strengthLevel"></div>
            <div className="strengthLevel"></div>
          </div>

          <div className="passwordRequirements">
            <section className="leftSide">
              <div className="requirementsLeft">
                <div className="PasswordStateSign">
                  <Check size={16} color="#16a34a" />
                </div>

                <h3>At least 10 characters</h3>
              </div>

              <div className="requirementsLeft">
                <div className="PasswordStateSign">
                  <img src={normaldarkCircle} alt="" />
                </div>

                <h3>One Symbol</h3>
              </div>
            </section>

            <section className="rightSide">
              <div className="requirementsRight">
                <div className="requirementsLeft">
                  <div className="PasswordStateSign">
                    <Check size={16} color="#16a34a" />
                  </div>

                  <h3>One Number</h3>
                </div>

                <div className="requirementsRight">
                  <div className="PasswordStateSign">
                    <Check size={16} color="#16a34a" />
                  </div>

                  <h3>Not a common password</h3>
                </div>
              </div>
            </section>
          </div>

          <div className="confirmSection">
            <h3>Confirm Password</h3>

            <div className="passwordInputWrapper">
              <input
                className="confirmPasswordInput"
                type={showPassword ? "text" : "password"}
                placeholder="Confirm Password"
                onChange={(e) => setConfirmPassword(e.target.value)}
              />

              <button
                type="button"
                aria-label={showPassword ? "Hide password" : "Show password"}
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <Eye size={20} /> : <EyeOff size={20} />}
              </button>
            </div>

            <div className="passwordMatchAnswer">
              <CircleX size={16} color="#b42318" />
              <h3>Passwords do not match</h3>
            </div>

            <div className="termsContainer">
              <input
                type="checkbox"
                id="agreeToTerms"
                name="agreeToTerms"
                required
              />

              <label htmlFor="agreeToTerms">
                I agree to the{" "}
                <a href="/terms" target="_blank" rel="noreferrer">
                  Terms
                </a>{" "}
                and{" "}
                <a href="/privacy-policy" target="_blank" rel="noreferrer">
                  Privacy Policy
                </a>
              </label>
            </div>

            {/* This is the create account button */}
            <button
              className="createAccountButton"
              onClick={handleCreateAccount}
            >
              Create Account →
            </button>

            <p className="signInText">
              Already have an account? <a href="/login">Sign in</a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default CreateAccount;
