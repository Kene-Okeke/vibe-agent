import VibeAndLogo from "../components/VibeAndLogo.jsx";
import darkcheck from "../assets/step-check-badge.png";
import uploadIcon from "../assets/upload-tile.png";
import inspectIcon from "../assets/inspect-tile.png";
import deployIcon from "../assets/deploy-tile.png";
import uploadzipIcon from "../assets/upload-zip-tile.png";
import uploadIconBlack from "../assets/upload-black.png";
import githubimportIcon from "../assets/import-github-tile.png";
import blackreactIcon from "../assets/react-vite-black.png";
import htmlIcon from "../assets/static-html-black.png";
import viteIcon from "../assets/vite-vanilla-black.png";
import "../css/Welcome.css";
import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

function Welcome() {
  const fileInputRef = useRef(null);

  const [Filename, setFilename] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [projectName, setProjectName] = useState("");
  const navigate = useNavigate();

  function handleUploadClick() {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }

  function storeChosenFile(event) {
    const file = event.target.files[0];
    if (file) {
      setFilename(file.name);

      setSelectedFile(file);
    }
  }

  async function handleUpload() {
    navigate("/create-account", {
      state: { file: selectedFile, projectName: projectName },
    });
  }

  return (
    <section className="mainContainer">
      <nav className="welcomeNav">
        {/*left section of nav with the vibedeploy text and icon */}
        <VibeAndLogo />
        {/* Account & Workspace + More*/}
        <div className="AccountandMore">
          <div className="numberOne">1</div>
          <div className="accountandcheck">
            <img className="darkCheck" src={darkcheck} alt="" />
            <h1>Account</h1>
            <hr className="horizontalLine" />
          </div>

          <div className="workspaceandcheck">
            <img className="darkCheck" src={darkcheck} alt="" />
            <h1>Workspace</h1>
            <hr className="horizontalLine" />
          </div>

          <div className="accountandcheck">
            <div className="numberThree">3</div>
            <h1>First project</h1>
            <hr className="horizontalLine" />
          </div>

          <div className="Skipandfive">
            <div className="skipText">Skip for now</div>
            <div className="numberFive">5</div>
          </div>
        </div>
      </nav>

      {/* Two Column Section*/}
      <section className="twoColumnSection">
        {/*Left column section */}
        <div className="leftColumn">
          <h1 className="welcomeplusname">WELCOME, KENE 👋</h1>

          <div className="heroAndTagline">
            <h1>Let’s ship your first project.</h1>
            <h3>
              Three steps, nothing hidden. You’ll see every stage your code goes
              through. <span className="number2">2</span>
            </h3>
          </div>

          <div className="threewidgetssection">
            <div className="uploadContainer">
              <div className="uploadIconandNumber">
                <img className="uploadimg" src={uploadIcon} alt="" />
                <span>01</span>
              </div>
              <div className="uploadandText">
                <h3>Upload</h3>
                <h1>Drop a ZIP of your project. We keep an exact snapshot.</h1>
              </div>
            </div>
            <div className="inspectContainer">
              <div className="inspectIconandNumber">
                <img className="inspectimg" src={inspectIcon} alt="" />
                <span>02</span>
              </div>
              <div className="uploadandText">
                <h3>Inspect</h3>
                <h1>
                  We read your files and detect framework and build steps.
                </h1>
              </div>
            </div>
            <div className="deployContainer">
              <div className="deployIconandNumber">
                <img className="deployimg" src={deployIcon} alt="" />
                <span>03</span>
              </div>
              <div className="uploadandText">
                <h3>Deploy</h3>
                <h1>We build, health-check and give you a live URL.</h1>
              </div>
            </div>
          </div>
        </div>

        {/*Right column section */}
        <div className="rightColumn">
          <h2>
            Project name <span className="optionalText">*</span>
          </h2>
          {/*my portfolio text and url */}
          <section className="inputContainer">
            <div className="projectInput">
              <input
                className="projectInput"
                type="text"
                placeholder="Enter Project Name"
                onChange={(e) => setProjectName(e.target.value)}
              />
            </div>

            <div className="portfolioTextStack">
              <h2 className="draftUrl">{projectName}.vibedeploy.app</h2>
            </div>
          </section>

          {/* this is the black widget with upload zip details */}
          <div className="uploadZipdarkWidget">
            <div className="iconandrecommendedCont">
              <img src={uploadzipIcon} alt="" />
              <div className="recommendedTextcont">RECOMMENDED</div>
            </div>
            <div className="uploadMainandSubtext">
              <span className="mainText">
                Upload a ZIP <span className="threeyellowcont">3</span>
              </span>
              <span className="subText">
                React + Vite projects are fully supported. Up to 100 MB.
              </span>
            </div>
            <input
              type="file"
              accept=".zip"
              ref={fileInputRef}
              onChange={storeChosenFile}
              hidden
            />
            <div className="uploadButtonContainer">
              <button
                className="uploadZipButton"
                onClick={handleUploadClick}
                disabled={selectedFile}
              >
                <img src={uploadIconBlack} alt="" />
                <h2>Choose ZIP file</h2>
              </button>
              <button
                className="uploadSourceButton"
                onClick={handleUpload}
                disabled={!selectedFile || !projectName}
              >
                <img src={deployIcon} alt="" />
                <h2>Deploy Project</h2>
              </button>
            </div>

            <div className="selectedFileName">{Filename}</div>
          </div>

          {/* this is the import frm git stack card with connect button */}
          <div className="importStackCont">
            <div className="imageCont">
              <img className="gitImportIcon" src={githubimportIcon} alt="" />
            </div>
            <div className="GitandTextCont">
              <div>
                Import from GitHub{" "}
                <div className="comingSoonText">Coming soon</div>
              </div>
              <h2>Connect a repository and deploy on every push.</h2>
            </div>
            <button className="connectCont">
              <h2>Connect</h2>
            </button>
          </div>
        </div>

        {/* this is the footer card with supported and coming next section */}
        <div className="supportedMainCont">
          <div className="supportedLeft">
            <h1 className="supportedText">SUPPORTED TODAY</h1>

            <div className="reactplusViteFlex">
              <img src={blackreactIcon} alt="" />
              <h1>React + Vite</h1>
            </div>
            <div className="viteVanilla">
              <img src={viteIcon} alt="" />
              <h1>Vite (vanilla)</h1>
            </div>
            <div className="staticHTML">
              <img src={htmlIcon} alt="" />
              <h1>Static HTML</h1>
            </div>
          </div>
          <div className="comingNextright">
            <h1 className="comingText">COMING NEXT</h1>

            <div className="reactplusViteFlex">
              <h1>Next.js</h1>
            </div>
            <div className="viteVanilla">
              <h1>Astro</h1>
            </div>
            <div className="staticHTML">
              <h1>Node APIs</h1>
            </div>
            <div className="GithubPush">
              <h1>GitHub push-to-deploy</h1>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default Welcome;
